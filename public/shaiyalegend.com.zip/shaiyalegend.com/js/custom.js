// function to calculate local time
// in a different city
// given the city's UTC offset
function calcTime(city, offset, date = null) {
  // create Date object for current location
  if (date) {
    var d = new Date(date);
  } else {
    var d = new Date();
  }
  // get UTC time in msec
  var utc = d.getTime() + (d.getTimezoneOffset() * 60000);
  // using supplied offset
  var nd = new Date(utc + (3600000 * parseInt(offset)));
  // return time as a string
  return nd.toString();
}

//Server time Cloack
function ServerTimeCloack() {
  // var currentTime = new Date(calcTime($TIMEZONE, $TIMEZONEOFFSET));
  var currentTime = new Date(calcTime($TIMEZONE, 1));
  var h = currentTime.getHours();
  var m = currentTime.getMinutes();
  var s = currentTime.getSeconds();
  setTimeout(function() {
    ServerTimeCloack();
  }, 1000);
  if (h < 10) {
    h = "0" + h;
  }
  if (m < 10) {
    m = "0" + m;
  }
  if (s < 10) {
    s = "0" + s;
  }
  var myClock = document.getElementById('server-time-cloack');
  if (myClock) {
    myClock.textContent = h + ":" + m + ":" + s;
    myClock.innerText = h + ":" + m + ":" + s;
  }
}

function loadUp(where, what) {
  $('html, body').css({ 'overflow': 'hidden', 'height': '100%' })
  $('#loginbox').modal('hide');
  $('.loading-body').fadeIn();
  $.post(what, function(data) {
    $('.loading-body').fadeOut();
    $(where).hide();
    $(where).html(data);
    $(where).fadeIn(0);
  });
  $('html, body').removeAttr('style')
}

function loadUpForm(where, what, formId) {
  $('html, body').css({ 'overflow': 'hidden', 'height': '100%' })
  $('.loading-body').fadeIn();
  $.post(what, $(formId).serialize(), function(data) {
    $('.loading-body').fadeOut();
    $(where).hide();
    $(where).html(data);
    $(where).fadeIn(0);
  });
  $('html, body').removeAttr('style')
}
